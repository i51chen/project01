create trigger `insert`
  before INSERT
  on tbl_student
  for each row
  BEGIN
	INSERT INTO tbl_u VALUES(new.id, new.name);
    END;

