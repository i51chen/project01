create procedure get_user_count(IN sex_id int, OUT user_count int)
  BEGIN
        IF sex_id = 0 THEN
    SELECT
        COUNT(*)
    FROM
        mybatis.p_user
    WHERE
        p_user.sex = '女'
    INTO user_count ; ELSE
SELECT
    COUNT(*)
FROM
    mybatis.p_user
WHERE
    p_user.sex = '男'
INTO user_count ;
    END IF ;
END;

