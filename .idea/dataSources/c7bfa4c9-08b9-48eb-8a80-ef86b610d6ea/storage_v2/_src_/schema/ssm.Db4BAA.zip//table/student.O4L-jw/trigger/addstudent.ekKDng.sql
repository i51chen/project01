create trigger addstudent
  before INSERT
  on student
  for each row
  BEGIN
INSERT INTO user (username) VALUES (student_no);
END;

