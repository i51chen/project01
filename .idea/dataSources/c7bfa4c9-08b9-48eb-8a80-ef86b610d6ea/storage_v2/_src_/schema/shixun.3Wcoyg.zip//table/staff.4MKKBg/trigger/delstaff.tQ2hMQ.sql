create trigger delstaff
  before DELETE
  on staff
  for each row
  BEGIN
	DELETE FROM user WHERE user.username=old.staff_no;
    END;

