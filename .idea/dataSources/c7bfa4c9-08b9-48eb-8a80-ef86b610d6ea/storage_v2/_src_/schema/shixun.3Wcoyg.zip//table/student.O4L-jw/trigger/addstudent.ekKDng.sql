create trigger addstudent
  before INSERT
  on student
  for each row
  BEGIN
INSERT INTO USER(username) VALUES(new.student_no);
END;

