create trigger addstaff
  before INSERT
  on staff
  for each row
  BEGIN
INSERT INTO user(username) VALUES(new.staff_no);
END;

