create trigger delstudent
  before DELETE
  on student
  for each row
  BEGIN
	DELETE FROM user WHERE 
    user.username = old.student_no;
    END;

